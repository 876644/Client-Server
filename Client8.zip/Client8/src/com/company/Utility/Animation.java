package com.company.Utility;

public class Animation {

}
