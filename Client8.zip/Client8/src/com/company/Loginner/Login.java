package com.company.Loginner;

import com.company.swing.swing;

import java.io.Serializable;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;



public class Login implements Serializable {
    public String login;
    public String password;
    private boolean newUser;
    public int r;
    public int g;
    public int b;
    private boolean approved = false;
    public boolean prev = true;

    private static final long serialVersionUID = 44;

    public void login(){
            swing.loginOfUser = null;
            swing.passwordOf = null;
            password = null;
            login = null;
            swing.openPassword();
            while (password == null){
                login = swing.loginOfUser;
                password = swing.passwordOf;
            }
            password = getMD5(password);
            newUser = swing.aBoolean;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public static String getMD5(String plaintext){
        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.reset();
            m.update(plaintext.getBytes());
            byte[] digest = m.digest();
            BigInteger bigInt = new BigInteger(1, digest);
            String hashtext = bigInt.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        }catch (NoSuchAlgorithmException e){
            e.printStackTrace();
            return null;
        }
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public boolean isNew(){
        return newUser;
    }

    public void setApproved(boolean approved){
        this.approved = approved;
    }

    public boolean isApproved(){
        return approved;
    }

}
