package com.company.language;

public class Locale_pl extends java.util.ListResourceBundle{
    @Override
    protected Object[][] getContents() {
        return new Object[][]{
                {"Enter.enter.button", "Zalogować"},
                { "Enter.regist.button", "Rejestracja"},
                {"Enter.lable.own", "Wpisz login i piankę:"},
                {"Enter.lable.user", "Wpisz login:"},
                {"Enter.lable.password", "Wpisz hasło:"},
                {"All.button.command", "Zespół"},
                {"All.button.visual", "Wizualizacja"},
                {"All.lable.menu", "Menu"},
                {"All.button.exit", "Wyjście"},
                {"All.button.table", "Tabela"},
                {"All.lable.user", "Użytkownik:"},
                {"All.button.filter", "Filtracja"}
        };
    }
}
