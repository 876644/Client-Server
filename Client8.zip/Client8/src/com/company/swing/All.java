package com.company.swing;

import com.company.Commands.Collection;
import com.company.Commands.remove_by_idCommand;
import com.company.Enums.*;
import com.company.Main;
import com.company.Utility.Board;
import com.company.Utility.Print;
import com.company.Utility.TimerEx;
import com.company.classes.StudyGroup;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import java.awt.*;
import java.util.PriorityQueue;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import static com.company.Main.*;
import static com.company.swing.swing.langW;

public class All  implements TableModelListener {
    public static JFrame frameA;
    private JPanel panelAll;
    private JButton tableButton;
    private JLabel MenuLable;
    private JButton filter;
    private JButton выходButton;
    private JButton командыButton;
    private JButton визуализацияButton;
    private JLabel lable;
    private JLabel lableUserOwn;

    public int[] row;
    private final PriorityQueue<StudyGroup> toCall = new PriorityQueue<>();

    public All() {
        lable.setText(l);
        trans();
        tableButton.addActionListener(e -> {
            JFrame jFrameTable = new JFrame("Table");
            int sizeOfCollection = collection.size();
            String[] columns = new String[] {"Id", "User","NameOfGroup", "X", "Y","Data","StudentsCount","FormEducation","Semester","Name","PassportID","EyeColor","HairColor","Nationality"};
            Object[][] data = new Object[sizeOfCollection][14];
            collection = message.objectForTable;
            for(int b = 1; b <= sizeOfCollection; b++) {

                StudyGroup ex = collection.poll();
                toCall.add(ex);
                if (ex != null) {
                    data[b-1][0] = ex.getId();
                    data[b-1][1] = ex.getUser();
                    data[b-1][2] = ex.getNameG();
                    data[b-1][3] = ex.getCoordinates().getX();
                    data[b-1][4] = ex.getCoordinates().getY();
                    data[b-1][5] = ex.getCreationDate();
                    data[b-1][6] = ex.getStudentsCount();
                    data[b-1][7] = ex.getFormOfEducation();
                    data[b-1][8] = ex.getSemesterEnum();
                    data[b-1][9] = ex.getGroupAdmin().getName();
                    data[b-1][10] = ex.getGroupAdmin().getPassportID();
                    data[b-1][11] = ex.getGroupAdmin().getEyeColor();
                    data[b-1][12] = ex.getGroupAdmin().getHairColor();
                    data[b-1][13] = ex.getGroupAdmin().getNationality();
                }
            }
            Main.collection.addAll(toCall);
            toCall.clear();

            JTable table = new JTable(data,columns);
            JPopupMenu popupMenu = new JPopupMenu();
            JMenuItem deleteItem = new JMenuItem("Delete");
            JMenuItem change = new JMenuItem("Change");
            popupMenu.add(deleteItem);
            popupMenu.add(change);
            table.setComponentPopupMenu(popupMenu);
            jFrameTable.add(new JScrollPane(table));
            jFrameTable.setSize(1200, 700);
            jFrameTable.setLocation(100,100);
            jFrameTable.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            jFrameTable.setVisible(true);

            deleteItem.addActionListener(e1 -> {
                int x = table.getSelectedRow();
                long id = (long) table.getModel().getValueAt(x,0);
                Main.object = new remove_by_idCommand(id);
                Main.sentCommandSwing();
                jFrameTable.dispose();
                JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
            });

            change.addActionListener(e1 -> {

                int r = table.getSelectedRow();
                int c = table.getSelectedColumn();

                if(l.equals(table.getModel().getValueAt(r, 1))) {

                    JFrame frame3 = new JFrame("New");
                    frame3.setSize(200,200);
                    JLabel label3 = new JLabel("Введите новые давнные.");
                    JButton button3 = new JButton("Выполнить");
                    JTextField textField3 = new JTextField();
                    frame3.add(label3, BorderLayout.NORTH);
                    frame3.add(textField3, BorderLayout.CENTER);
                    frame3.add(button3, BorderLayout.SOUTH);
                    frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    frame3.setVisible(true);

                    for(StudyGroup p: collection){
                        if(p.getId() == (long) table.getModel().getValueAt(r, 0)){
                            switch (c){
                                case 2 ->
                                    button3.addActionListener(e2 -> {
                                        if(textField3.getText().equals("") || !Pattern.compile("[A-Z]*[a-z]*\\d*").matcher(textField3.getText()).matches())
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else {p.setNameG(textField3.getText());
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 3 ->
                                    button3.addActionListener(e2 -> {
                                        if(!Pattern.compile("\\d+").matcher(textField3.getText()).matches()||!Pattern.compile("\\d.*\\d*").matcher(textField3.getText()).matches() || textField3.getText().equals(""))
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else if (Double.parseDouble(textField3.getText()) > 887) JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                             else{
                                                 p.getCoordinates().setX(Double.valueOf(textField3.getText()));
                                                 frame3.dispose();
                                                 jFrameTable.dispose();
                                                 object = new Collection();
                                                 message.objectForTable = collection;
                                                 sentCommandSwing();
                                                 JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 4->
                                        button3.addActionListener(e2 -> {
                                            if(!Pattern.compile("\\d+").matcher(textField3.getText()).matches())
                                                JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                            else {
                                                p.getCoordinates().setY(Integer.valueOf(textField3.getText()));
                                                frame3.dispose();
                                                jFrameTable.dispose();
                                                object = new Collection();
                                                message.objectForTable = collection;
                                                sentCommandSwing();
                                                JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                            }
                                        });
                                case 5 -> JOptionPane.showInternalMessageDialog(null,"Эти данные нельзя изменить.","Message", JOptionPane.WARNING_MESSAGE);
                                case 6->
                                    button3.addActionListener(e2 -> {
                                        if(!Pattern.compile("\\d+").matcher(textField3.getText()).matches())
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else if (Long.parseLong(textField3.getText()) <= 0) JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                             else {p.setStudentsCount(Long.valueOf(textField3.getText()));
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 7->
                                    button3.addActionListener(e2 -> {
                                        if((!textField3.getText().equals("FULL_TIME_EDUCATION")&&!textField3.getText().equals("DISTANCE_EDUCATION")&&!textField3.getText().equals("EVENING_CLASSES")))
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else {p.setFormOfEducation(FormOfEducation.valueOf(textField3.getText()));
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 8 ->
                                    button3.addActionListener(e2 -> {
                                        if(!textField3.getText().equals("FIFTH")&&!textField3.getText().equals("SIXTH")&&!textField3.getText().equals("SEVENTH"))
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else {p.setSemesterEnum(Semester.valueOf(textField3.getText()));
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 9 ->
                                    button3.addActionListener(e2 -> {
                                        if(textField3.getText().equals("") || !Pattern.compile("[A-Z]*[a-z]*").matcher(textField3.getText()).matches())
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else {p.getGroupAdmin().setName(textField3.getText());
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 10->
                                    button3.addActionListener(e2 -> {
                                        if(textField3.getText().equals("") || !Pattern.compile("[A-Z]*[a-z]*").matcher(textField3.getText()).matches())
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else if(((textField3.getText()).length()) > 31) JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                             else {p.getGroupAdmin().setPassportID(textField3.getText());
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 11 ->
                                    button3.addActionListener(e2 -> {
                                        if(!textField3.getText().equals("GREEN")&&!textField3.getText().equals("YELLOW")&&!textField3.getText().equals("ORANGE")&&!textField3.getText().equals("WHITE"))
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else {p.getGroupAdmin().setEyeColor(ColorEye.valueOf(textField3.getText()));
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 12 ->
                                    button3.addActionListener(e2 -> {
                                        if(!textField3.getText().equals("GREEN")&&!textField3.getText().equals("RED")&&!textField3.getText().equals("YELLOW")&&!textField3.getText().equals("WHITE"))
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else {p.getGroupAdmin().setEyeColor(ColorEye.valueOf(textField3.getText()));
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                                case 13 ->
                                    button3.addActionListener(e2 -> {
                                        if(!textField3.getText().equals("RUSSIA")&&!textField3.getText().equals("GERMANY")&&!textField3.getText().equals("CHINA")&&!textField3.getText().equals("NORTH_KOREA"))
                                            JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                        else{ p.getGroupAdmin().setEyeColor(ColorEye.valueOf(textField3.getText()));
                                            frame3.dispose();
                                            jFrameTable.dispose();
                                            object = new Collection();
                                            message.objectForTable = collection;
                                            sentCommandSwing();
                                            JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                        }
                                    });
                            }
                        }
                    }

                }else JOptionPane.showInternalMessageDialog(null,"Вы не можете редактировать чужой объект","Message", JOptionPane.WARNING_MESSAGE);
            });
            change.addActionListener(e1 -> {
                table.getModel().addTableModelListener(this);
            });
        });

        filter.addActionListener(e -> ColumnFilter.columnMethod());
        выходButton.addActionListener(e -> {frameA.dispose();System.exit(1);});
        командыButton.addActionListener(e -> CommandsSwing.CommandMethod());
        визуализацияButton.addActionListener(e -> {
            Print.printMain();
        });
    }
    public static void doPanelAll() {
        frameA = new JFrame("App");
        frameA.setSize(700, 700);
        frameA.setLocation(400,100);
        frameA.setContentPane(new All().panelAll);
        frameA.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameA.setVisible(true);
    }

    public void trans(){
        swing.resourceBundle = ResourceBundle.getBundle("com.company.language.Locale", langW);
        MenuLable.setText(swing.resourceBundle.getString("All.lable.menu"));
        командыButton.setText(swing.resourceBundle.getString("All.button.command"));
        визуализацияButton.setText(swing.resourceBundle.getString("All.button.visual"));
        выходButton.setText(swing.resourceBundle.getString("All.button.exit"));
        tableButton.setText(swing.resourceBundle.getString("All.button.table"));
        filter.setText(swing.resourceBundle.getString("All.button.filter"));
        lableUserOwn.setText(swing.resourceBundle.getString("All.lable.user"));
    }

    @Override
    public void tableChanged(TableModelEvent e) {
            }
}
