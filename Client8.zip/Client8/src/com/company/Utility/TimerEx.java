package com.company.Utility;

import com.company.classes.StudyGroup;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

import static com.company.Main.*;
import static com.company.Utility.Print.twoCXOll;

public class TimerEx extends JComponent implements MouseListener, ActionListener{
public static Timer timer;
private static final int COUNTER_MAX = 30;
public static ArrayList<MovingStudyGroup> collectionForAnimate = new ArrayList<MovingStudyGroup>();

    public TimerEx(){
        twoCXOll.clear();
        addMouseListener(this);
        for (int i =1;i<= collection.size();i++){
            StudyGroup example = collection.poll();
            twoCXOll.add(example);
            collectionForAnimate.add(new MovingStudyGroup(example.getCoordinates().getX(),example.getCoordinates().getY(),example,example.getStudentsCount()));
        }
        collection.addAll(twoCXOll);
    }

    public void startTimer() {
        timer.start();
    }

    @Override
    public void paint(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        moveSG(g2);
    }

    public void moveSG(Graphics2D g2){
        for(MovingStudyGroup movingStudyGroup: collectionForAnimate){
            if(movingStudyGroup.tic<0){
                System.out.println("i don't know");
            }
            movingStudyGroup.tic--;
            movingStudyGroup.x+=5;
            movingStudyGroup.y+=5;
            drawSG(g2, (int) movingStudyGroup.x,movingStudyGroup.y, (int) movingStudyGroup.size);
        }
    }
    public void drawSG(Graphics2D graphics2D,int x,int y,int size){
        Color color =  new Color(r,h,b);
        Ellipse2D ellipse2D = new Ellipse2D.Double(x,y,size,size);
        graphics2D.fill(ellipse2D);
    }
    @Override
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    public static class MovingStudyGroup{
        private double x;
        private int y;
        private int tic = COUNTER_MAX;
        private final StudyGroup studyGroup;
        private double size;

        public MovingStudyGroup(double x, int y, StudyGroup studyGroup, double size) {
            this.x = x;
            this.y = y;
            this.studyGroup = studyGroup;
            this.size = size;
        }
    }
}