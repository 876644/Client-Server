package com.company.language;

public class Locale_ru extends java.util.ListResourceBundle{

    @Override
    protected Object[][] getContents() {
        return new Object[][]{
                {"Enter.enter.button", "Войти"},
                { "Enter.regist.button", "Зарегестрироваться"},
                {"Enter.lable.own", "Введите логин и пороль:"},
                {"Enter.lable.user", "Введите логин:"},
                {"Enter.lable.password", "Введите пороль:"},
                {"All.button.command", "Команды"},
                {"All.button.visual", "Визуализация"},
                {"All.lable.menu", "Меню"},
                {"All.button.exit", "Выход"},
                {"All.button.table", "Таблица"},
                {"All.lable.user", "Пользователь:"},
                {"All.button.filter", "Фильтрация"}

        };
    }
}
