package com.company.Commands;

public class helpCommand extends AbstractCommand {

    private static final long serialVersionUID = 8;

}
