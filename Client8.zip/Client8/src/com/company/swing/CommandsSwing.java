package com.company.swing;

import com.company.Commands.*;
import com.company.Main;
import com.company.classes.StudyGroup;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.PriorityQueue;
import java.util.regex.Pattern;

import static com.company.Main.collection;
import static com.company.Main.message;

public class CommandsSwing {
    private JPanel panelCommand;
    private JButton clearButton;
    private JButton remove_headButton;
    private JButton historyButton;
    private JButton infoButton;
    private JButton average_of_students_countButton;
    private JButton remove_by_idButton;
    private JButton updateButton;
    private JButton addButton;
    private JButton helpButton;
    private JButton showButton;
    private JButton headButton;
    private JButton filter_by_form_of_educationButton;
    private JButton remove_any_students_countButton;
    public static JFrame frameCommand;
    private final PriorityQueue<StudyGroup> toCall = new PriorityQueue<>();

    public CommandsSwing() {
        clearButton.addActionListener(e -> {
            frameCommand.dispose();
            Main.object = new clearCommand();
            Main.sentCommandSwing();
            JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
        });
        addButton.addActionListener(e -> {
            frameCommand.dispose();
            AddSwing.AddMethod();
        });
        infoButton.addActionListener(e -> {
            frameCommand.dispose();
            Main.object = new infoCommand();
            Main.sentCommandSwing();
            JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);

        });
        helpButton.addActionListener(e -> {
            frameCommand.dispose();
            Main.object = new helpCommand();
            Main.sentCommandSwing();
            JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);

        });
        historyButton.addActionListener(e -> {
            frameCommand.dispose();
            Main.object = new historyCommand();
            Main.sentCommandSwing();
            JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);

        });
        showButton.addActionListener(e -> {
            JFrame jFrameTable = new JFrame("Table");
            int sizeOfCollection = collection.size();
            String[] columns = new String[] {"Id", "User","NameOfGroup", "X", "Y","Data","StudentsCount","FormEducation","Semester","Name","PassportID","EyeColor","HairColor","Nationality"};
            Object[][] data = new Object[sizeOfCollection][14];
            collection = message.objectForTable;
            for(int b = 1; b <= sizeOfCollection; b++) {

                StudyGroup ex = collection.poll();
                toCall.add(ex);
                if (ex != null) {
                    data[b-1][0] = ex.getId();
                    data[b-1][1] = ex.getUser();
                    data[b-1][2] = ex.getNameG();
                    data[b-1][3] = ex.getCoordinates().getX();
                    data[b-1][4] = ex.getCoordinates().getY();
                    data[b-1][5] = ex.getCreationDate();
                    data[b-1][6] = ex.getStudentsCount();
                    data[b-1][7] = ex.getFormOfEducation();
                    data[b-1][8] = ex.getSemesterEnum();
                    data[b-1][9] = ex.getGroupAdmin().getName();
                    data[b-1][10] = ex.getGroupAdmin().getPassportID();
                    data[b-1][11] = ex.getGroupAdmin().getEyeColor();
                    data[b-1][12] = ex.getGroupAdmin().getHairColor();
                    data[b-1][13] = ex.getGroupAdmin().getNationality();
                }
            }
            Main.collection.addAll(toCall);
            toCall.clear();
            JTable table = new JTable(data,columns);
            jFrameTable.add(new JScrollPane(table));
            jFrameTable.setSize(1200, 700);
            jFrameTable.setLocation(100,100);
            jFrameTable.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            jFrameTable.setVisible(true);
        });
        remove_headButton.addActionListener(e -> {
            frameCommand.dispose();
            Main.object = new remove_headCommand();
            Main.sentCommandSwing();
            JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
        });
        headButton.addActionListener(e -> {
            frameCommand.dispose();
            Main.object = new headCommand();
            Main.sentCommandSwing();
            JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
        });
        average_of_students_countButton.addActionListener(e -> {
            frameCommand.dispose();
            Main.object = new average_of_students_countCommand();
            Main.sentCommandSwing();
            JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
        });
        filter_by_form_of_educationButton.addActionListener(e -> {
            frameCommand.dispose();
            JFrame frame3 = new JFrame("remove_any_by_students_count");
            frame3.setSize(200,200);
            JLabel label3 = new JLabel("Введите кформу образования.");
            JButton button3 = new JButton("Выполнить");
            JTextField textField3 = new JTextField();
            frame3.add(label3, BorderLayout.NORTH);
            frame3.add(textField3, BorderLayout.CENTER);
            frame3.add(button3, BorderLayout.SOUTH);
            frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame3.setVisible(true);
            button3.addActionListener(e1 -> {
                if(!textField3.getText().equals("FULL_TIME_EDUCATION") && !textField3.getText().equals("DISTANCE_EDUCATION") &&! textField3.getText().equals("EVENING_CLASSES")){
                    textField3.setText("");
                    JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Повторите попытку.","Message", JOptionPane.WARNING_MESSAGE);
                }else {
                    frame3.dispose();
                    Main.object = new filter_by_form_of_educationCommand(textField3.getText());
                    Main.sentCommandSwing();
                    JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
                }
            });
        });
        remove_any_students_countButton.addActionListener(e -> {
            frameCommand.dispose();
            JFrame frame3 = new JFrame("remove_any_by_students_count");
            frame3.setSize(200,200);
            JLabel label3 = new JLabel("Введите колличество студентов.");
            JButton button3 = new JButton("Выполнить");
            JTextField textField3 = new JTextField();
            frame3.add(label3, BorderLayout.NORTH);
            frame3.add(textField3, BorderLayout.CENTER);
            frame3.add(button3, BorderLayout.SOUTH);
            frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame3.setVisible(true);
            button3.addActionListener(e1 -> {
                if(!Pattern.compile("\\d+").matcher(textField3.getText()).matches()){
                    textField3.setText("");
                    JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Повторите попытку.","Message", JOptionPane.WARNING_MESSAGE);
                }else {
                    frame3.dispose();
                    Long count = Long.valueOf(textField3.getText());
                    Main.object = new remove_any_by_students_countCommand(count);
                    Main.sentCommandSwing();
                    JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
                }
            });
        });
        remove_by_idButton.addActionListener(e -> {
            frameCommand.dispose();
            JFrame frame3 = new JFrame("Remove_by_id");
            frame3.setSize(200,200);
            JLabel label3 = new JLabel("Введите ID.");
            JButton button3 = new JButton("Выполнить");
            JTextField textField3 = new JTextField();
            frame3.add(label3, BorderLayout.NORTH);
            frame3.add(textField3, BorderLayout.CENTER);
            frame3.add(button3, BorderLayout.SOUTH);
            frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame3.setVisible(true);
            button3.addActionListener(e1 -> {
                if(!Pattern.compile("\\d+").matcher(textField3.getText()).matches()){
                    textField3.setText("");
                    JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Повторите попытку.","Message", JOptionPane.WARNING_MESSAGE);
                }else {
                    frame3.dispose();
                    Long Id = Long.valueOf(textField3.getText());
                    Main.object = new remove_by_idCommand(Id);
                    Main.sentCommandSwing();
                    JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
                }
            });
        });
        updateButton.addActionListener(e -> {
            frameCommand.dispose();
            JFrame frame3 = new JFrame("Remove_by_id");
            frame3.setSize(200,200);
            JLabel label3 = new JLabel("Введите ID.");
            JButton button3 = new JButton("Выполнить");
            JTextField textField3 = new JTextField();
            frame3.add(label3, BorderLayout.NORTH);
            frame3.add(textField3, BorderLayout.CENTER);
            frame3.add(button3, BorderLayout.SOUTH);
            frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame3.setVisible(true);
            button3.addActionListener(e1 -> {
                if(!Pattern.compile("\\d+").matcher(textField3.getText()).matches()){
                    textField3.setText("");
                    JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Повторите попытку.","Message", JOptionPane.WARNING_MESSAGE);
                }else {
                    frame3.dispose();
                    Long Id = Long.valueOf(textField3.getText());
                    Main.object = new updateCommand(Id);
                    Main.sentCommandSwing();
                    JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
                    if (Main.message.message.equals("Данные элемента с таким iD был найден и удалён. Введите новые двнные элемента")) AddSwing.AddMethod();
                }
            });
        });
    }

    public static void CommandMethod(){
        Main.object = null;
        frameCommand = new JFrame("Commands");
        frameCommand.setSize(700, 700);
        frameCommand.setLocation(400,100);
        frameCommand.setContentPane(new CommandsSwing().panelCommand);
        frameCommand.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameCommand.setVisible(true);
    }
}
