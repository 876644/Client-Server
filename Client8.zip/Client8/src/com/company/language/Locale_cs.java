package com.company.language;

public class Locale_cs extends java.util.ListResourceBundle{

    @Override
    protected Object[][] getContents() {
        return new Object[][]{
                {"Enter.enter.button", "Vstoupit"},
                {"Enter.regist.button", "Registrace"},
                {"Enter.lable.own", "Zadejte přihlašovací jméno a pěnu:"},
                {"Enter.lable.user", "Zadejte přihlašovací údaje:"},
                {"Enter.lable.password", "Zadejte heslo:"},
                {"All.button.command", "Posádky"},
                {"All.button.visual", "Vizualizace"},
                {"All.lable.menu", "Menu"},
                {"All.button.exit", "Výstup"},
                {"All.button.table", "Tabulka"},
                {"All.lable.user", "Uživatel:"},
                {"All.button.filter", "Filtrování"}
        };
    }
}
