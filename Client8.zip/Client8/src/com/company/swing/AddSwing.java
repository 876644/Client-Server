package com.company.swing;

import com.company.Commands.addCommand;
import com.company.Enums.*;
import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

public class AddSwing {
    private JPanel panelAdd;
    public static JFrame frameAdd;
    private JTextField nameGroup;
    private JButton button1;
    private JTextField x;
    private JTextField y;
    private JTextField studentsCount;
    private JTextField semesterEnum;
    private JTextField name;
    private JTextField formEducation;
    private JTextField passportID;
    private JTextField eyeColor;
    private JTextField hairColor;
    private JTextField nationality;

    public AddSwing() {
        button1.addActionListener(e -> {
            int count = 0;
            if(nameGroup.getText().equals("") || !Pattern.compile("[A-Z]*[a-z]*\\d*").matcher(nameGroup.getText()).matches()){
                nameGroup.setText("");
                count = 1;
            }
            if(!Pattern.compile("\\d+").matcher(x.getText()).matches()||!Pattern.compile("\\d.*\\d*").matcher(x.getText()).matches() || x.getText().equals("")){
               x.setText("");
               count = 1;
            }else  if(Double.parseDouble(x.getText()) > 887){
                x.setText("");
                count = 1;
            }
            if(!Pattern.compile("\\d+").matcher(y.getText()).matches()){
                y.setText("");
                count = 1;
            }
            if((!Pattern.compile("\\d+").matcher(studentsCount.getText()).matches())){
                studentsCount.setText("");
                count = 1;
            }else if (Long.parseLong(studentsCount.getText()) <= 0){
                studentsCount.setText("");
                count = 1;
            }
            if (!formEducation.getText().equals("FULL_TIME_EDUCATION")&&!formEducation.getText().equals("DISTANCE_EDUCATION")&&!formEducation.getText().equals("EVENING_CLASSES")){
                formEducation.setText("");
                count = 1;
            }
            if (!semesterEnum.getText().equals("FIFTH")&&!semesterEnum.getText().equals("SIXTH")&&!semesterEnum.getText().equals("SEVENTH")){
                semesterEnum.setText("");
                count = 1;
            }
            if (name.getText().equals("") || !Pattern.compile("[A-Z]*[a-z]*").matcher(name.getText()).matches() ){
                name.setText("");
                count = 1;
            }
            if (passportID.getText().equals("") || (!Pattern.compile("[A-Z]*[a-z]*\\d*").matcher(passportID.getText()).matches())){
                passportID.setText("");
                count = 1;
            }else if(passportID.getText().length() > 31){
                passportID.setText("");
                count = 1;
            }
            if (!eyeColor.getText().equals("GREEN")&&!eyeColor.getText().equals("YELLOW")&&!eyeColor.getText().equals("ORANGE")&&!eyeColor.getText().equals("WHITE")){
                eyeColor.setText("");
                count = 1;
            }
            if (!hairColor.getText().equals("GREEN")&&!hairColor .getText().equals("RED")&&!hairColor .getText().equals("YELLOW")&&!hairColor .getText().equals("WHITE")){
                hairColor.setText("");
                count = 1;
            }
            if (!nationality.getText().equals("RUSSIA")&&!nationality.getText().equals("GERMANY")&&!nationality.getText().equals("CHINA")&&!nationality.getText().equals("NORTH_KOREA")){
                nationality.setText("");
                count = 1;
            }
            if (count == 0){
                Main.object = null;

                Main.object = new addCommand(nameGroup.getText(),Double.parseDouble(x.getText()),Integer.valueOf(y.getText()),Long.valueOf(studentsCount.getText()), FormOfEducation.valueOf(formEducation.getText()), Semester.valueOf(semesterEnum.getText()),name.getText(),passportID.getText(), ColorEye.valueOf(eyeColor.getText()), ColorHair.valueOf(hairColor.getText()), Country.valueOf(nationality.getText()));
                Main.object.toString();
                Main.sentCommandSwing();
                frameAdd.dispose();
                JOptionPane.showInternalMessageDialog(null,Main.message.message,"Message", JOptionPane.WARNING_MESSAGE);
            }else JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Повторите попытку.","Message", JOptionPane.WARNING_MESSAGE);
        });
    }

    public static void AddMethod(){
        frameAdd = new JFrame("Add");
        frameAdd.setSize(600, 700);
        frameAdd.setLocation(400,100);
        frameAdd.setContentPane(new AddSwing().panelAdd);
        frameAdd.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameAdd.setVisible(true);
    }
}
