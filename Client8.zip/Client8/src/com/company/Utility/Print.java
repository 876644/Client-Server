package com.company.Utility;

import com.company.Commands.Collection;
import com.company.Enums.ColorEye;
import com.company.Enums.FormOfEducation;
import com.company.Enums.Semester;
import com.company.Main;
import com.company.classes.StudyGroup;
import com.company.swing.AddSwing;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.regex.Pattern;

import static com.company.Main.*;
import static java.lang.Thread.sleep;

public class Print extends JComponent implements MouseListener, ActionListener {

    public static ArrayList<StudyGroup> twoCXOll = new ArrayList<>();
    public static ArrayList<Ellipse2D> allEllipses = new ArrayList<>();
    public static Ellipse2D ellipse2D;
    public static long size;
    public static JButton button;
    public static int x ;
    public static int y;

    public Print() {
        addMouseListener(this);
    }


    protected void paintComponent(Graphics g) {
        int sizeOfCollection = collection.size();
        Graphics2D graphics2D = (Graphics2D) g;

        for (int i = 1; i <= sizeOfCollection; i++) {

            StudyGroup example = collection.poll();
            twoCXOll.add(example);
            if (example != null) {
                if (example.getUser().equals("ggg")) {
                    r = 120;
                    h = 4;
                    b = 89;
                }

                double d = example.getCoordinates().getX();
                 x = (int) d;
                 y = example.getCoordinates().getY();
                size = example.getStudentsCount();
                if (size < 100) size = size + 60;

                    ellipse2D = new Ellipse2D.Double(x, y, size, size);
                    allEllipses.add(ellipse2D);

                    (graphics2D).fill(ellipse2D);

                    Color color = new Color(r, h, b);
                    graphics2D.setColor(color);

            }
        }
        collection.addAll(twoCXOll);

    }

    public static void printMain() {
        twoCXOll.clear();
        JFrame frameVisual = new JFrame("Visual");
        frameVisual.setSize(1100, 1100);
        JMenuBar menuBar = new JMenuBar();
        button = new JButton("Change");
        menuBar.add("mmm",button);
        button.addActionListener(e -> {
            JFrame frame3 = new JFrame("New");
            frame3.setSize(200,200);
            JLabel label3 = new JLabel("Введите id oбъекта, которого хотите изменить.");
            JButton button3 = new JButton("Выполнить");
            JTextField textField3 = new JTextField();
            frame3.add(label3, BorderLayout.NORTH);
            frame3.add(textField3, BorderLayout.CENTER);
            frame3.add(button3, BorderLayout.SOUTH);
            frame3.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame3.setVisible(true);
            button3.addActionListener(e1 -> {
                for(StudyGroup p:twoCXOll){
                    if(p.getId() == Long.parseLong(textField3.getText())){
                        if (l.equals(p.getUser())){
                            frame3.dispose();
                            JFrame frame4 = new JFrame("New");
                            frame4.setSize(200,200);
                            JLabel label4 = new JLabel("Введите поле, которе хотите изменить.");
                            JButton button4 = new JButton("Выполнить");
                            JTextField textField4 = new JTextField();
                            frame4.add(label4, BorderLayout.NORTH);
                            frame4.add(textField4, BorderLayout.CENTER);
                            frame4.add(button4, BorderLayout.SOUTH);
                            frame4.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                            frame4.setVisible(true);

                            button4.addActionListener(e2 -> {

                                frame4.dispose();
                                JFrame frame5 = new JFrame("New");
                                frame5.setSize(200,200);
                                JLabel label5 = new JLabel("Введите новые данные поля.");
                                JButton button5 = new JButton("Выполнить");
                                JTextField textField5 = new JTextField();
                                frame5.add(label5, BorderLayout.NORTH);
                                frame5.add(textField5, BorderLayout.CENTER);
                                frame5.add(button5, BorderLayout.SOUTH);
                                frame5.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                                frame5.setVisible(true);
                                switch (textField4.getText().toLowerCase()){
                                    case "имя группы" ->{
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(textField5.getText().equals("") || !Pattern.compile("[A-Z]*[a-z]*\\d*").matcher(textField5.getText()).matches())
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {
                                                    p.setNameG(textField5.getText());
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }

                                            });}
                                    case "x" ->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(!Pattern.compile("\\d+").matcher(textField5.getText()).matches()||!Pattern.compile("\\d.*\\d*").matcher(textField5.getText()).matches() || textField5.getText().equals(""))
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else if (Double.parseDouble(textField5.getText()) > 887) JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {
                                                    p.getCoordinates().setX(Double.valueOf(textField5.getText()));
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                                }
                                            });
                                    case "y"->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(!Pattern.compile("\\d+").matcher(textField5.getText()).matches())
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {
                                                    p.getCoordinates().setY(Integer.valueOf(textField5.getText()));
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null, message.message, "Message", JOptionPane.WARNING_MESSAGE);
                                                }
                                            });
                                    case "дата" -> JOptionPane.showInternalMessageDialog(null,"Эти данные нельзя изменить.","Message", JOptionPane.WARNING_MESSAGE);
                                    case "колличество студентов"->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(!Pattern.compile("\\d+").matcher(textField5.getText()).matches())
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else if (Long.parseLong(textField5.getText()) <= 0) JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {p.setStudentsCount(Long.valueOf(textField5.getText()));
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }
                                            });
                                    case "форма образования"->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if((!textField5.getText().equals("FULL_TIME_EDUCATION")&&!textField5.getText().equals("DISTANCE_EDUCATION")&&!textField5.getText().equals("EVENING_CLASSES")))
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {p.setFormOfEducation(FormOfEducation.valueOf(textField5.getText()));
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }
                                            });
                                    case "семестр" ->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(!textField5.getText().equals("FIFTH")&&!textField5.getText().equals("SIXTH")&&!textField5.getText().equals("SEVENTH"))
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else{ p.setSemesterEnum(Semester.valueOf(textField5.getText()));
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }
                                            });
                                    case "имя студента" ->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(textField5.getText().equals("") || !Pattern.compile("[A-Z]*[a-z]*").matcher(textField5.getText()).matches())
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {p.getGroupAdmin().setName(textField5.getText());
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }
                                            });
                                    case "паспортные данные" ->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(textField5.getText().equals("") || !Pattern.compile("[A-Z]*[a-z]*").matcher(textField5.getText()).matches())
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else if(((textField5.getText()).length()) > 31) JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {p.getGroupAdmin().setPassportID(textField5.getText());
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }
                                            });
                                    case "цвет глаз" ->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(!textField5.getText().equals("GREEN")&&!textField5.getText().equals("YELLOW")&&!textField5.getText().equals("ORANGE")&&!textField5.getText().equals("WHITE"))
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {p.getGroupAdmin().setEyeColor(ColorEye.valueOf(textField5.getText()));
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }
                                            });
                                    case "цвет волос" ->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(!textField5.getText().equals("GREEN")&&!textField5.getText().equals("RED")&&!textField5.getText().equals("YELLOW")&&!textField5.getText().equals("WHITE"))
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else{ p.getGroupAdmin().setEyeColor(ColorEye.valueOf(textField5.getText()));
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }
                                            });
                                    case "национальность" ->
                                            button5.addActionListener(e3 -> {
                                                frame5.dispose();
                                                frameVisual.dispose();
                                                if(!textField5.getText().equals("RUSSIA")&&!textField5.getText().equals("GERMANY")&&!textField5.getText().equals("CHINA")&&!textField5.getText().equals("NORTH_KOREA"))
                                                    JOptionPane.showInternalMessageDialog(null,"Вы неправильно ввели данные.","Message", JOptionPane.WARNING_MESSAGE);
                                                else {p.getGroupAdmin().setEyeColor(ColorEye.valueOf(textField5.getText()));
                                                    object = new Collection();
                                                    message.objectForTable = collection;
                                                    sentCommandSwing();
                                                    JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                                                }
                                            });
                                }
                            });
                        }else {
                            JOptionPane.showInternalMessageDialog(null, "Вы не можете редактировать чужой объект", "Message", JOptionPane.WARNING_MESSAGE);
                            frame3.dispose();
                        }
                    }
                }
            });

        });
        frameVisual.add(menuBar, BorderLayout.NORTH);
        frameVisual.setLocation(50, 0);
        frameVisual.setResizable(false);
        frameVisual.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameVisual.getContentPane().add(new Print(),BorderLayout.CENTER);
       /* Timer timer = new Timer(1000/60,new MyActionListener());
        timer.start();*/
        frameVisual.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        int x = e.getX();
        int y = e.getY();
        int count = 0;


        for(Ellipse2D ellipse2D1:allEllipses){
            count++;
            if(ellipse2D1.contains(x,y)){
                StudyGroup ex = twoCXOll.get(count-1);

                String text = "Номер iD: " + ex.getId() +"\n" +
                        "Пользователь" + ex.getUser() + "\n" +
                        "Имя группы: " + ex.getNameG() + "\n" +
                        "Координата x: " + ex.getCoordinates().getX() + "\n" +
                        "Координата y: " + ex.getCoordinates().getY() + "\n" +
                        "Дата: " + ex.getCreationDate() +"\n" +
                        "Колличество студентов: " + ex.getStudentsCount() + "\n" +
                        "Форма обучения: " + ex.getFormOfEducation() + "\n" +
                        "Сместр: " + ex.getSemesterEnum() + "\n" +
                        "Имя студента: " + ex.getGroupAdmin().getName() + "\n" +
                        "iD паспорта: " + ex.getGroupAdmin().getPassportID() + "\n" +
                        "Цвет глаз: " + ex.getGroupAdmin().getEyeColor() + "\n" +
                        "Цвет волос: " + ex.getGroupAdmin().getHairColor() + "\n" +
                        "Национальность: " + ex.getGroupAdmin().getNationality();
                JOptionPane.showInternalMessageDialog(null,text,"Info", JOptionPane.WARNING_MESSAGE);



            }
        }
    }
/*
    public static void mainPrint() {
        javax.swing.SwingUtilities.invokeLater(Print::printMain);
    }*/

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }/*
    public static class MyActionListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            ellipse2D.setFrame(x++,y,size,size);
        }
    }*/
}
