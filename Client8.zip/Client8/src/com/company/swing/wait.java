package com.company.swing;

import javax.swing.*;

public class wait {
    public static JFrame frameW;
    private JPanel panelWaiting;

    public static void waitAnswer(){
        frameW = new JFrame("Ожидание");
        frameW.setContentPane(new wait().panelWaiting);
        frameW.setSize(400,400);
        frameW.setLocation(400,200);
        frameW.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameW.setVisible(true);
    }
}
