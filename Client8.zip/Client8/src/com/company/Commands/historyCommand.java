package com.company.Commands;

public class historyCommand extends AbstractCommand {
    private static final long serialVersionUID = 20;
}
