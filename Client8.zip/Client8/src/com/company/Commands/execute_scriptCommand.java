package com.company.Commands;

public class execute_scriptCommand extends AbstractCommand {
    private static final long serialVersionUID = 5;
}
