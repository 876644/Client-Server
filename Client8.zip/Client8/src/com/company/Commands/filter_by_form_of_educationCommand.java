package com.company.Commands;

import com.company.Enums.FormOfEducation;

public class filter_by_form_of_educationCommand extends AbstractCommand {
    public String formOfEducation;
    private static final long serialVersionUID = 6;

    public filter_by_form_of_educationCommand(String formOfEducation) {
        this.formOfEducation = formOfEducation;
    }
}
