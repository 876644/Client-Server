package com.company.swing;

import com.company.Enums.*;
import com.company.Main;
import com.company.classes.StudyGroup;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.company.Main.collection;
import static com.company.swing.ColumnFilter.col;

public class EnumFilter {

    private JTextField textField1;
    private JButton фильтроватьButton;
    private JPanel panelEnum;
    public static JFrame frameEnum;
    public static PriorityQueue<StudyGroup> cCollection = new PriorityQueue<>();
    public static ArrayList<StudyGroup> toCallTable = new ArrayList<>();

    public EnumFilter() {
        cCollection.clear();
        фильтроватьButton.addActionListener(e -> {
            System.out.println(col);
            switch (col){
                case "форма обучения" ->{
                    if (!(textField1.getText().equals("FULL_TIME_EDUCATION"))&&!(textField1.getText().equals("DISTANCE_EDUCATION"))&&!(textField1.getText().equals("EVENING_CLASSES"))) {
                        textField1.setText("");
                        JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Попробуйте заново.","Message", JOptionPane.WARNING_MESSAGE);
                    }else {
                        frameEnum.dispose();
                        ArrayList<StudyGroup> twoCollection;
                        twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getFormOfEducation() == FormOfEducation.valueOf(textField1.getText())).collect(Collectors.toList());
                        cCollection.addAll(twoCollection);
                        addTable();
                    }
                }
                case "семестр" -> {
                    if(!textField1.getText().equals("FIFTH")&&!textField1.getText().equals("SIXTH")&&!textField1.getText().equals("SEVENTH")) {
                        textField1.setText("");
                        JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Попробуйте заново.","Message", JOptionPane.WARNING_MESSAGE);
                    }else {
                        frameEnum.dispose();
                        ArrayList<StudyGroup> twoCollection;
                        twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getSemesterEnum() == Semester.valueOf(textField1.getText())).collect(Collectors.toList());
                        cCollection.addAll(twoCollection);
                        addTable();
                    }
                }
                case "цвет глаз" -> {
                    if(!textField1.getText().equals("GREEN")&&!textField1.getText().equals("YELLOW")&&!textField1.getText().equals("ORANGE")&&!textField1.getText().equals("WHITE")) {
                        textField1.setText("");
                        JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Попробуйте заново.","Message", JOptionPane.WARNING_MESSAGE);
                    }else {
                        frameEnum.dispose();
                        ArrayList<StudyGroup> twoCollection;
                        twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getGroupAdmin().getEyeColor() == ColorEye.valueOf(textField1.getText())).collect(Collectors.toList());
                        cCollection.addAll(twoCollection);
                        addTable();
                    }
                }
                case "цвет волос" -> {
                    if(!textField1.getText().equals("GREEN")&&!textField1.getText().equals("RED")&&!textField1.getText().equals("YELLOW")&&!textField1.getText().equals("WHITE")){
                        textField1.setText("");
                        JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Попробуйте заново.","Message", JOptionPane.WARNING_MESSAGE);
                    }else {
                        frameEnum.dispose();
                        ArrayList<StudyGroup> twoCollection;
                        twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getGroupAdmin().getHairColor() == ColorHair.valueOf(textField1.getText())).collect(Collectors.toList());
                        cCollection.addAll(twoCollection);
                        addTable();
                    }
                }
                case "национальность" ->{
                    if(!textField1.getText().equals("RUSSIA")&&!textField1.getText().equals("GERMANY")&&!textField1.getText().equals("CHINA")&&!textField1.getText().equals("NORTH_KOREA")){
                        textField1.setText("");
                        JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Попробуйте заново.","Message", JOptionPane.WARNING_MESSAGE);
                    }else {
                        frameEnum.dispose();
                        ArrayList<StudyGroup> twoCollection;
                        twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getGroupAdmin().getNationality() == Country.valueOf(textField1.getText())).collect(Collectors.toList());
                        cCollection.addAll(twoCollection);
                        addTable();
                    }
                }
                case "пользователь" ->{
                    frameEnum.dispose();
                    ArrayList<StudyGroup> twoCollection;
                    twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getUser().equals(textField1.getText())).collect(Collectors.toList());
                    cCollection.addAll(twoCollection);
                    addTable();
                }
            }
        });
    }

    public static void enumMethod(){
        frameEnum = new JFrame("Filter");
        frameEnum.setSize(300, 300);
        frameEnum.setLocation(400,200);
        frameEnum.setContentPane(new EnumFilter().panelEnum);
        frameEnum.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameEnum.setVisible(true);
    }

    public static void addTable(){
        JFrame jFrameTable = new JFrame("Table");
        int sizeOfCollection = cCollection.size();
        String[] columns = new String[] {"Id", "User","NameOfGroup", "X", "Y","Data","StudentsCount","FormEducation","Semester","Name","PassportID","EyeColor","HairColor","Nationality"};
        Object[][] data = new Object[sizeOfCollection][14];

        for(int b = 1; b <= sizeOfCollection; b++) {

            StudyGroup ex = cCollection.poll();
            toCallTable.add(ex);
            if (ex != null) {
                data[b-1][0] = ex.getId();
                data[b-1][1] = ex.getUser();
                data[b-1][2] = ex.getNameG();
                data[b-1][3] = ex.getCoordinates().getX();
                data[b-1][4] = ex.getCoordinates().getY();
                data[b-1][5] = ex.getCreationDate();
                data[b-1][6] = ex.getStudentsCount();
                data[b-1][7] = ex.getFormOfEducation();
                data[b-1][8] = ex.getSemesterEnum();
                data[b-1][9] = ex.getGroupAdmin().getName();
                data[b-1][10] = ex.getGroupAdmin().getPassportID();
                data[b-1][11] = ex.getGroupAdmin().getEyeColor();
                data[b-1][12] = ex.getGroupAdmin().getHairColor();
                data[b-1][13] = ex.getGroupAdmin().getNationality();
            }
        }
        cCollection.addAll(toCallTable);
        toCallTable.clear();

        JTable table = new JTable(data,columns);
        jFrameTable.add(new JScrollPane(table));
        jFrameTable.setSize(1200, 700);
        jFrameTable.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jFrameTable.setVisible(true);
    }
}
