package com.company.Commands;

public class headCommand extends AbstractCommand {

    private static final long serialVersionUID = 7;

}
