package com.company.swing;

import com.company.language.Locale_ru;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

public class swing {
    public static JFrame frame;
    public JPanel Panel;
    public JButton войтиButton;
    private JFormattedTextField логин;
    private JButton bb;
    private JPasswordField passwordField1;
    private JComboBox comboBox1;
    private JLabel lableOwn;
    private JLabel lablePassword;
    private JLabel lableUser;
    public static String loginOfUser;
    public static String passwordOf;
    public static Boolean aBoolean;
    public static Locale langW;
    public static String language;
    public static ResourceBundle resourceBundle;
    public swing() {
        войтиButton.addActionListener(e -> {
            loginOfUser = логин.getText();
            passwordOf = passwordField1.getText();
            //System.out.println(loginOfUser);
            aBoolean = false;
            frame.dispose();
            wait.waitAnswer();
        });

        bb.addActionListener(e -> {
            loginOfUser = логин.getText();
            passwordOf = passwordField1.getText();
            aBoolean = true;
            frame.dispose();
            wait.waitAnswer();
        });

        comboBox1.addActionListener(e -> {
            comboBox1 = (JComboBox) e.getSource();
            language = String.valueOf(comboBox1.getSelectedItem());
            switch (language){
                case "русский" ->{
                    langW = new Locale("ru");
                    resourceBundle = ResourceBundle.getBundle("com.company.language.Locale", langW);
                    translate();
                }
                case "польский" ->{
                    langW = new Locale("pl");
                    resourceBundle = ResourceBundle.getBundle("com.company.language.Locale", langW);
                    translate();
                }
                case "чешский" ->{
                    langW = new Locale("cs");
                    resourceBundle = ResourceBundle.getBundle("com.company.language.Locale", langW);
                    translate();
                }case "английский" ->{
                    langW = new Locale("en");
                    resourceBundle = ResourceBundle.getBundle("com.company.language.Locale", langW);
                    translate();
                }
            }
        });
    }
    private void translate(){
        войтиButton.setText(resourceBundle.getString("Enter.enter.button"));
        bb.setText(resourceBundle.getString("Enter.regist.button"));
        lableOwn.setText(resourceBundle.getString("Enter.lable.own"));
        lablePassword.setText(resourceBundle.getString("Enter.lable.password"));
        lableUser.setText(resourceBundle.getString("Enter.lable.user"));

    }
    public static void openPassword (){
        frame = new JFrame("Log in");
        frame.setContentPane(new swing().Panel);
        frame.setSize(400,400);
        frame.setLocation(400,200);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
