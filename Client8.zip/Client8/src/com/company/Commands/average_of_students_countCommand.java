package com.company.Commands;

public class average_of_students_countCommand extends AbstractCommand {

    private static final long serialVersionUID = 4;

}
