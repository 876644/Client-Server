package com.company.Commands;

public class exitCommand extends AbstractCommand {
    public void exit(){
        System.out.println("Клиентское приложение завершило работу.");
        System.exit(1);
    }
}
