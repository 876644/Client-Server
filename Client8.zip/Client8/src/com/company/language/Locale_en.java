package com.company.language;

public class Locale_en extends java.util.ListResourceBundle{
    @Override
    protected Object[][] getContents() {
        return new Object[][]{
                {"Enter.enter.button", "Enter"},
                {"Enter.regist.button", "Registration"},
                {"Enter.lable.own", "Enter your username and password:"},
                {"Enter.lable.user", "Enter your username:"},
                {"Enter.lable.password", "Enter your password:"},
                {"All.button.command", "Commands"},
                {"All.button.visual", "Visualization"},
                {"All.lable.menu", "Menu"},
                {"All.button.exit", "Exit"},
                {"All.button.table", "Table"},
                {"All.lable.user", "User:"},
                {"All.button.filter", "Filter"}
        };
    }
}
