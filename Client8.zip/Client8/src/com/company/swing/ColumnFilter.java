package com.company.swing;

import javax.swing.*;

public class ColumnFilter {
    private JComboBox comboBox1;
    private JPanel panelColumn;
    private JButton фильтроватьButton;
    public static JFrame frameColumn;
    public static String col;

    public ColumnFilter() {
        comboBox1.addActionListener(e -> {comboBox1 = (JComboBox) e.getSource();col = String.valueOf(comboBox1.getSelectedItem());});
        фильтроватьButton.addActionListener(e -> {
            if(col.equals("id")||col.equals("x")||col.equals("y")||col.equals("колличество студентов")){
                frameColumn.dispose();
                CountFilter.countMethod();
            }else {
                frameColumn.dispose();
                EnumFilter.enumMethod();
            }
        });
    }

    public static void columnMethod(){
        frameColumn = new JFrame("Filter");
        frameColumn.setSize(400, 200);
        frameColumn.setLocation(400,200);
        frameColumn.setContentPane(new ColumnFilter().panelColumn);
        frameColumn.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameColumn.setVisible(true);
    }


}
