package com.company.Commands;

public class infoCommand extends AbstractCommand {
    private static final long serialVersionUID = 9;
}
