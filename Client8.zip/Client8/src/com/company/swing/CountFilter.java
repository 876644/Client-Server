package com.company.swing;

import com.company.Enums.ColorEye;
import com.company.classes.StudyGroup;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.company.Main.collection;
import static com.company.swing.ColumnFilter.col;

public class CountFilter {
    private JPanel panelCount;
    private JComboBox comboBox1;
    private JTextField textField1;
    private JButton фильтроватьButton;
    public static JFrame frameCount;
    public String sign;
    public static PriorityQueue<StudyGroup> cCollectionC = new PriorityQueue<>();
    public static ArrayList<StudyGroup> toCallTableC = new ArrayList<>();


    public CountFilter() {
        comboBox1.addActionListener(e -> {comboBox1 = (JComboBox) e.getSource();sign = String.valueOf(comboBox1.getSelectedItem());});

        фильтроватьButton.addActionListener(e -> {
            cCollectionC.clear();
            if (!Pattern.compile("\\d+").matcher(textField1.getText()).matches()) {
                textField1.setText("");
                JOptionPane.showInternalMessageDialog(null,"Неправильно введены данные. Попробуйте заново.","Message", JOptionPane.WARNING_MESSAGE);
            }else {
                switch (col){
                    case "id" -> {
                        frameCount.dispose();
                        ArrayList<StudyGroup> twoCollection = null;
                        switch (sign){
                            case "=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getId().equals(Long.valueOf(textField1.getText()))).collect(Collectors.toList());
                            case "<" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getId() < Long.parseLong(textField1.getText())).collect(Collectors.toList());
                            case "<=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getId() <= Long.parseLong(textField1.getText())).collect(Collectors.toList());
                            case ">" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getId() > Long.parseLong(textField1.getText())).collect(Collectors.toList());
                            case ">=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getId() >= Long.parseLong(textField1.getText())).collect(Collectors.toList());
                        }
                        cCollectionC.addAll(twoCollection);
                        addTableCount();
                    }
                    case "колличество студентов" ->{
                        frameCount.dispose();
                        ArrayList<StudyGroup> twoCollection = null;
                        switch (sign){
                            case "=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getStudentsCount().equals(Long.valueOf(textField1.getText()))).collect(Collectors.toList());
                            case "<" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getStudentsCount()< Long.parseLong(textField1.getText())).collect(Collectors.toList());
                            case "<=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getStudentsCount()<= Long.parseLong(textField1.getText())).collect(Collectors.toList());
                            case ">" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getStudentsCount() > Long.parseLong(textField1.getText())).collect(Collectors.toList());
                            case ">=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getStudentsCount()>= Long.parseLong(textField1.getText())).collect(Collectors.toList());

                        }
                        cCollectionC.addAll(twoCollection);
                        addTableCount();
                    }
                    case "x" ->{
                            frameCount.dispose();
                        ArrayList<StudyGroup> twoCollection = null;
                        switch (sign){
                            case "=" ->twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getX().equals(Double.valueOf(textField1.getText()))).collect(Collectors.toList());
                            case "<" ->twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getX()< Double.parseDouble(textField1.getText())).collect(Collectors.toList());
                            case "<=" ->twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getX()<= Double.parseDouble(textField1.getText())).collect(Collectors.toList());
                            case ">" ->twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getX()> Double.parseDouble(textField1.getText())).collect(Collectors.toList());
                            case ">=" ->twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getX()>= Double.parseDouble(textField1.getText())).collect(Collectors.toList());
                        }
                        cCollectionC.addAll(twoCollection);
                        addTableCount();
                    }
                    case "y" ->{
                        frameCount.dispose();
                        ArrayList<StudyGroup> twoCollection;
                        switch (sign){
                            case "=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getY().equals(Integer.valueOf(textField1.getText()))).collect(Collectors.toList());
                            case "<" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getY() < Integer.parseInt(textField1.getText())).collect(Collectors.toList());
                            case "<=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getY() <= Integer.parseInt(textField1.getText())).collect(Collectors.toList());
                            case ">=" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getY() > Integer.parseInt(textField1.getText())).collect(Collectors.toList());
                            case ">" -> twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getY() >= Integer.parseInt(textField1.getText())).collect(Collectors.toList());

                        }
                        twoCollection = (ArrayList<StudyGroup>) collection.stream().filter(collection -> collection.getCoordinates().getY().equals(Integer.valueOf(textField1.getText()))).collect(Collectors.toList());
                        cCollectionC.addAll(twoCollection);
                        addTableCount();
                    }
                }
            }
        });
    }

    public static void countMethod(){
        frameCount = new JFrame("Example");
        frameCount.setSize(400, 400);
        frameCount.setLocation(400,200);
        frameCount.setContentPane(new CountFilter().panelCount);
        frameCount.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameCount.setVisible(true);
    }

    public static void addTableCount(){
        JFrame jFrameTable = new JFrame("Table");
        int sizeOfCollection = cCollectionC.size();
        String[] columns = new String[] {"Id", "User","NameOfGroup", "X", "Y","Data","StudentsCount","FormEducation","Semester","Name","PassportID","EyeColor","HairColor","Nationality"};
        Object[][] data = new Object[sizeOfCollection][14];

        for(int b = 1; b <= sizeOfCollection; b++) {

            StudyGroup ex = cCollectionC.poll();
            toCallTableC.add(ex);
            if (ex != null) {
                data[b-1][0] = ex.getId();
                data[b-1][1] = ex.getUser();
                data[b-1][2] = ex.getNameG();
                data[b-1][3] = ex.getCoordinates().getX();
                data[b-1][4] = ex.getCoordinates().getY();
                data[b-1][5] = ex.getCreationDate();
                data[b-1][6] = ex.getStudentsCount();
                data[b-1][7] = ex.getFormOfEducation();
                data[b-1][8] = ex.getSemesterEnum();
                data[b-1][9] = ex.getGroupAdmin().getName();
                data[b-1][10] = ex.getGroupAdmin().getPassportID();
                data[b-1][11] = ex.getGroupAdmin().getEyeColor();
                data[b-1][12] = ex.getGroupAdmin().getHairColor();
                data[b-1][13] = ex.getGroupAdmin().getNationality();
            }
        }
        cCollectionC.addAll(toCallTableC);
        toCallTableC.clear();

        JTable table = new JTable(data,columns);
        jFrameTable.add(new JScrollPane(table));
        jFrameTable.setSize(1200, 700);
        jFrameTable.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jFrameTable.setVisible(true);
    }
}
