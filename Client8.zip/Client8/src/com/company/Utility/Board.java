package com.company.Utility;

import com.company.classes.StudyGroup;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;

import static com.company.Main.*;
import static com.company.Main.collection;
import static com.company.Utility.Print.allEllipses;
import static com.company.Utility.Print.twoCXOll;

public class Board {
    public static JFrame mainFrame = new JFrame("lol");
    public static TimerEx timerEx;

    public void printGraphics(){
        mainFrame.setVisible(true);
        JPanel mainPanel = new JPanel();
        mainPanel.add(timerEx);
        timerEx.startTimer();
        mainFrame.setContentPane(mainPanel);
        mainFrame.revalidate();
        mainFrame.repaint();

    }
}
