package com.company.Commands;


import java.io.Serializable;


public class Collection extends AbstractCommand implements Serializable {

    private static final long serialVersionUID = 111;

}
