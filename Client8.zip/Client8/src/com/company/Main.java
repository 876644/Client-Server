package com.company;

import com.company.Commands.*;
import com.company.Loginner.Login;
import com.company.Utility.Creation;
import com.company.Utility.Message;
import com.company.classes.StudyGroup;
import com.company.swing.All;
import com.company.swing.swing;

import javax.swing.*;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.logging.Logger;

import static com.company.swing.swing.*;
import static com.company.swing.wait.frameW;
//ssh -L 50002:pg:5432 s336960@helios.se.ifmo.ru -p 2222
//psql -h pg studs

    //При нажатии на объект должна выводиться информация об этом объекте.
    //При отрисовке объекта должна воспроизводиться согласованная с преподавателем анимация.
//Возможность редактирования отдельных полей любого из объектов (принадлежащего пользователю). Переход к редактированию объекта возможен из области с визуализацией объекта.
//язык и локализ...


public class Main {

    public static AbstractCommand object;
    public static Message message;
    static DatagramChannel channel;
    public static String l = null;
    public static String p = null;
    public static byte[] sendingDataBuffer;
    public static Login login;
    public static int r;
    public static int h;
    public static int b;
    public static  int port = 21055; //порт сервера, к которому собирается потключится клиентский сокет
    public static PriorityQueue<StudyGroup> collection = new PriorityQueue<>();

    public static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) throws IOException {
        logger.info("Program has started!");
        sentCommand();
    }

    public static byte[] serialize(Object obj) throws IOException{

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();//данные записываются в массив байтов
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
        objectOutputStream.writeObject(obj);//Записывает указанный объект в ObjectOutputStream
        objectOutputStream.flush();//Сбрасывает поток
        return byteArrayOutputStream.toByteArray();

    }

    public static Object deserialize(byte[] array) throws IOException, ClassNotFoundException{

        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(array);
        ObjectInput objectInput = new ObjectInputStream(byteArrayInputStream);
        return objectInput.readObject();
    }

    public static void sentCommand(){

        sendingDataBuffer = null;

        try {

            channel = DatagramChannel.open();
            channel.configureBlocking(false);
            login = new Login();
            message = new Message("",collection,p,l, aBoolean,r,h,b);

            while(message.newMes){
                login.login();
                l = login.getLogin();
                p = login.getPassword();
                InetSocketAddress inetSocketAddress = new InetSocketAddress("localhost",port);
                channel = DatagramChannel.open();
                channel.configureBlocking(false);

                Message message1 = new Message("",collection,p,l,aBoolean,r,h,b);
                System.out.println(l + " " + p);
                sendingDataBuffer = serialize(message1);
                ByteBuffer byteBuffer = ByteBuffer.wrap(sendingDataBuffer);
                channel.send(byteBuffer, inetSocketAddress);
                System.out.println("Команда была отправлена.");

                ByteBuffer newByteBuffer = ByteBuffer.allocate(16384);
                SocketAddress a = channel.receive(newByteBuffer);
                long timeStart = System.currentTimeMillis();

                while (a == null) {
                    if ((System.currentTimeMillis() - timeStart) < 5000){
                        a = channel.receive(newByteBuffer);
                    }else {
                        frameW.dispose();
                        JOptionPane.showInternalMessageDialog(null,"Сервер не отвечает. Повторите попытку позже.","Message", JOptionPane.WARNING_MESSAGE);
                        System.exit(0);
                    }
                }
                message = (Message) deserialize(newByteBuffer.array());
                r = message.r;
                h = message.g;
                b = message.b;
                System.out.println(r);


                JOptionPane.showInternalMessageDialog(null,message.message,"Message", JOptionPane.WARNING_MESSAGE);

                frameW.dispose();
                channel.close();
                collection = message.objectForTable;
            }
            All.doPanelAll();

        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
            logger.severe("Error!");
        }
    }
    public static void sentCommandSwing(){
        try {
                InetSocketAddress inetSocketAddress = new InetSocketAddress("localhost", port);
                channel = DatagramChannel.open();
                channel.configureBlocking(false);

                Message message1 = new Message("", collection, p, l, aBoolean,r,h,b);
                message1.object = object;
                message1.newMes = false;
                sendingDataBuffer = serialize(message1);
                ByteBuffer byteBuffer = ByteBuffer.wrap(sendingDataBuffer);
                channel.send(byteBuffer, inetSocketAddress);
                System.out.println("Команда была отправлена.");

                ByteBuffer newByteBuffer = ByteBuffer.allocate(16384);
                SocketAddress a = channel.receive(newByteBuffer);
                while (a == null) {
                    a = channel.receive(newByteBuffer);
                }
                message = (Message) deserialize(newByteBuffer.array());
                collection = message.objectForTable;

                channel.close();

        }catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
            logger.severe("Error!");
        }
    }

}


